console.log("Hello!");
