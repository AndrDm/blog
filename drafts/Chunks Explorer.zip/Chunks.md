Just to "complete" parallelization topic - there is one more "fine tuning" thing - called Chunks.

By default LabVIEW will partition iterations automatically.

To understand chunks I would like to recommend to make very simple experiment, where you will log threads execution - begin end end with help of Queue.

So, the  worker looks like this:

and main loop like that:

Now you will see the order of the execution, and the iteration are not called sequentially, this is how "auto partition" works. If you will change amount of iteration or amount of threads, then this pattern also will be changed.

Now if you will enable Chunks, and connect to this terminal, let say "1", then you will see which elements will be used first:

If you will connect "2", then every second elementh will be used, if "3", then 3rd and so on. So you can control order of execution.

Take a note, that you can connect here also array, then you can handle more complicated scenarios, for example, I will connect array with 1,2,3,4,5,6,7,8, then you will see, the patter - first and second used, then one gap, then 3rd and so on, every element in Chunks array is the distance between consecutive elements, which will be processed.

Normally in most cases the auto partitioning works just fine in case if the execution time for each iteration more or less the same, but in some special cases, if different iteration taking significantly different time and you know the pattern, then  you can get better performance. 

For example, I will increase processing time for every 8th iteration:

Now with default settings the overall time will take 2,3 seconds. Nothing wrong in the middle of parallele for loop's execution, but at the end it is not efficient, some cores will be not occupied, because 1s parallelized with 0,1, you will see it in the log:

But if I will set chunks to 8, then the "heavy" iterations will be processed in same chunk, then CPU will be continuously occupied and overall time will be 1,7 seconds - means 0,6 seconds better than before.

I wrote this, because in discussed case the time of the Gauss-Lobatto Quadrature computation is very depends from the Limits, so it could be your case when different iterations will take different time.

I will recommend to try to adjust chunks only at the end and only if needed, otherwise you can get slower execution than default. As Donald Knuth said - premature optimization is root of all evils"

---

Just to 'complete' the parallelization topic - there is one more 'fine-tuning' thing called Chunks.

By default, LabVIEW will partition iterations automatically.

To understand chunks, I would like to recommend making a very simple experiment where you log thread execution - beginning and end - with the help of a Queue.

So, the worker looks like this:

and the main loop looks like that:

Now you will see the order of execution, and the iterations are not called sequentially; this is how 'auto partition' works. If you change the number of iterations or the number of threads, this pattern will also change.

Now, if you enable Chunks and connect to this terminal, let's say '1', then you will see which elements will be used first:

If you connect '2', then every second element will be used; if '3', then every third, and so on. So you can control the order of execution.

Note that you can also connect an array here instead of scalar. Then you can handle more complicated scenarios. For example, if I connect an array with 1,2,3,4,5,6,7,8, then you will see the pattern - first and second used, then one gap, then 3rd and so on. Every element in the Chunks array is the distance between consecutive elements which will be processed.

Normally, in most cases, auto partitioning works just fine if the execution time for each iteration is more or less the same. But in some special cases, if different iterations take significantly different times and you know the pattern, then you can get better performance.

For example, I will increase processing time for every 8th iteration:

Now, with default settings, the overall time will take 2.3 seconds. Nothing wrong in the middle of the parallel for loop's execution, but at the end it is not efficient; some cores will not be occupied because 1s is parallelized with 0.1s. You will see it in the log:

But if I set chunks to 8, then the 'heavy' iterations will be processed in the same chunk. The CPU will be continuously occupied, and the overall time will be 1.7 seconds - meaning 0.6 seconds better than before.

I wrote this because, in the discussed case, the time of the Gauss-Lobatto Quadrature computation depends heavily on the limits. So it could be your case where different iterations will take different amounts of time.

But I recommend trying to adjust chunks only at the end and only if needed; otherwise, you can get slower execution than default. 

As Donald Knuth said, 'Premature optimization is the root of all evil.'