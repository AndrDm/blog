//==============================================================================
//
// Title:		CacheEstimation
// Purpose:		A short description of the command-line tool.
//
// Created on:	21.04.2025 at 11:20:24 by Andrey Dmitriev.
// Copyright:	GE Inspection Technologies GmbH. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <ansi_c.h>
#include <windows.h>
#include <stdio.h>

#define SIZE_1GiB (1024 * 1024 * 1024)
#define ITERATIONS 100

double measure_access_time(char* array, size_t size) {
    LARGE_INTEGER freq, start, end;
    QueryPerformanceFrequency(&freq);
    
    // Warm up the cache
    for(size_t i = 0; i < size; i += 64) {
        array[i] = 0;
    }

    QueryPerformanceCounter(&start);
    for(int iter = 0; iter < ITERATIONS; iter++) {
        for(size_t i = 0; i < size; i += 64) {
            array[i] = (char)iter;
        }
    }
    QueryPerformanceCounter(&end);

    return (double)(end.QuadPart - start.QuadPart) / freq.QuadPart * 1e9 / (size/64 * ITERATIONS);
}

int main() {
    char* array = (char*)malloc(SIZE_1GiB);
    if(!array) return 1;

    // Test different strides to detect cache boundaries
    size_t test_sizes[] = {32*1024, 256*1024, 8*1024*1024, SIZE_1GiB};
    const char* level_names[] = {"L1", "L2", "L3", "RAM"};

    for(int i = 0; i < 4; i++) {
        double time = measure_access_time(array, test_sizes[i]);
        printf("%s (~%d KB) access time: %.2f ns\n", 
               level_names[i], 
               test_sizes[i]/1024, 
               time);
    }

    free(array);
    return 0;
}
