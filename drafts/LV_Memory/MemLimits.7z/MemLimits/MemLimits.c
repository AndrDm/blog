//==============================================================================
//
// Title:		MemLimits
// Purpose:		A short description of the command-line tool.
//
// Created on:	19.04.2025 at 07:19:09 by Andrey Dmitriev.
// Copyright:	GE Inspection Technologies GmbH. All Rights Reserved.
//
//==============================================================================

#include <windows.h>
#include <ansi_c.h>

int main (int argc, char *argv[])
{
#ifdef _WIN64
	int GiB = 0;
	while (malloc(1024*1024*1024)) printf("%d GiB allocated\n", ++GiB);
#else
	int MiB = 0;
	while (malloc(1024*1024)) printf("%d MiB allocated\n", ++MiB);
#endif	
	printf("No more allocations possible\n");
	return 0;
}

