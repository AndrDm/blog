//==============================================================================
//
// Title:		CacheLineWithinAcross
// Purpose:		A short description of the command-line tool.
//
// Created on:	22.04.2025 at 00:06:25 by Andrey Dmitriev.
// Copyright:	GE Inspection Technologies GmbH. All Rights Reserved.
//
//==============================================================================


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <ansi_c.h>


#define CACHE_LINE_SIZE 64
#define ITERATIONS 100000000
#define WARMUP 10000000
LARGE_INTEGER Start, End;

void* aligned_malloc(size_t size, size_t alignment) {
    // Validate alignment is power of 2
    if (alignment == 0 || (alignment & (alignment - 1)) != 0) {
        return NULL;
    }

    // Calculate required space with padding for alignment and storage
    size_t total_size = size + alignment + sizeof(void*);
    void* original = malloc(total_size);
    
    if (!original) return NULL;

    // Calculate aligned address after storage space
    uintptr_t raw_addr = (uintptr_t)original + sizeof(void*);
    uintptr_t aligned_addr = (raw_addr + alignment - 1) & ~(alignment - 1);

    // Store original pointer before aligned block
    *((void**)(aligned_addr - sizeof(void*))) = original;

    return (void*)aligned_addr;
}

void aligned_free(void* ptr) {
    if (!ptr) return;
    
    // Retrieve original pointer from before aligned block
    void* original = *((void**)((uintptr_t)ptr - sizeof(void*)));
    free(original);
}

typedef struct {
    volatile uint8_t data[CACHE_LINE_SIZE];  // Single cache line
} CacheLine;

typedef struct {
    volatile uint8_t data[CACHE_LINE_SIZE*2];  // Single cache line
} CacheLine2;

void measure_within_cache_line() {
    // Allocate single cache line with proper alignment
   CacheLine *line = aligned_malloc(CACHE_LINE_SIZE, /* sizeof(CacheLine) */ 4096);
   //CacheLine *line = malloc(CACHE_LINE_SIZE);
    
    volatile uint8_t *ptr = line->data;
    
    // Warm-up
    for(int i=0; i<WARMUP; i++) {
        ptr[i % CACHE_LINE_SIZE] = (uint8_t)i;
    }

    // Measurement - access all elements in cache line
	QueryPerformanceCounter(&Start);
	char sum = 0;
    for(int i=0; i<ITERATIONS; i++) {
        *ptr = (uint8_t)i;
		sum += *ptr;
        ptr += 1;  // Move within cache line
        ptr = line->data + (ptr - line->data) % CACHE_LINE_SIZE;  // Wrap around
    }
	QueryPerformanceCounter(&End);
    double latency = (End.QuadPart - Start.QuadPart) * 100.0 / ITERATIONS; //100 th nanoseconds
    
    //free(line);
    aligned_free(line);
    printf("Same cache line access - Latency: %.2f ns %d\n", latency, sum);
}

void measure_across_cache_lines() {
    // Allocate two cache lines
    CacheLine2 *lines = aligned_malloc(CACHE_LINE_SIZE*2, sizeof(CacheLine) / 2);
    //CacheLine *lines = malloc(CACHE_LINE_SIZE);
    
    volatile uint8_t *ptr = lines[0].data;
    int cross_boundary = 0;
	char sum = 0;
	QueryPerformanceCounter(&Start);
    for(int i=0; i<ITERATIONS; i++) {
        *ptr = (uint8_t)i;
		sum += *ptr;
        ptr += 128;  // Jump to next cache line
        ptr = lines[0].data + (ptr - lines[0].data) % (2 * CACHE_LINE_SIZE);
        cross_boundary += (ptr == lines[0].data);  // Track boundary crosses
    }
	QueryPerformanceCounter(&End);
    double latency = (End.QuadPart - Start.QuadPart) * 100.0 / ITERATIONS; //100 th nanoseconds
    
    //free(lines);
    aligned_free(lines);
    

    printf("Cross-cache-line access - Latency: %.2f ns (Boundary crosses: %d) %d\n", 
           latency, cross_boundary, sum);
}


int main() {
    measure_within_cache_line();
	measure_across_cache_lines();
    return 0;
}
