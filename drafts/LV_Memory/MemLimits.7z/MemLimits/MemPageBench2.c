//==============================================================================
//
// Title:		MemLimits
// Purpose:		A short description of the command-line tool.
//
// Created on:	19.04.2025 at 07:19:09 by Andrey Dmitriev.
// https://learn.microsoft.com/en-us/windows/win32/sysinfo/acquiring-high-resolution-time-stamps
//==============================================================================

#include <windows.h>
#include <ansi_c.h>

#define MB 1024*1024
int main (int argc, char *argv[])
{
	LARGE_INTEGER Start, End, Freq;
	QueryPerformanceFrequency (&Freq);
 	double freq_ms = (double)Freq.QuadPart / 1000.0;

	uint8_t* ptr = (uint8_t*)malloc(1024 * MB);

	QueryPerformanceCounter(&Start); // Activity to be timed
	ZeroMemory(ptr, 1024 * MB); // Here we have Page Faults
	QueryPerformanceCounter(&End);
	printf("First ZeroMemory %f ms\n", (End.QuadPart - Start.QuadPart) / freq_ms);
	
	QueryPerformanceCounter(&Start);
	ZeroMemory(ptr, 1024 * MB); // Here all pages already mapped
	QueryPerformanceCounter(&End);
	printf("Second ZeroMemory %f ms\n", (End.QuadPart - Start.QuadPart) / freq_ms);
	
	free(ptr);
	return 0;
}
