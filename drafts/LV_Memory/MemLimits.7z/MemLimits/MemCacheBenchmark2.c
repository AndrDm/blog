//==============================================================================
//
// Title:		MemLimits
// Purpose:		A short description of the command-line tool.
//
// Created on:	19.04.2025 at 07:19:09 by Andrey Dmitriev.
// https://learn.microsoft.com/en-us/windows/win32/sysinfo/acquiring-high-resolution-time-stamps
//==============================================================================

#include <windows.h>
#include <ansi_c.h>

#define MB 1024*1024
int main (int argc, char *argv[])
{
	uint8_t sum = 0;	
	LARGE_INTEGER Start, End, Freq;

	QueryPerformanceFrequency (&Freq);
 	double freq_ms = Freq.QuadPart / 1000.0;

	uint8_t* ptr = (uint8_t*)malloc(1024 * MB);
	ZeroMemory(ptr, 1024 * MB);

	QueryPerformanceCounter(&Start); // Activity to be timed
	for(int i = 0; i < (1024 * MB)/64; i++) sum += ptr[i];
	QueryPerformanceCounter(&End);
	printf("Sequential access %f ms\n", (End.QuadPart - Start.QuadPart) / freq_ms);
	
	QueryPerformanceCounter(&Start); // Access with 64 bytes step
	for(int i = 0; i < (1024 * MB); i += 64) sum += ptr[i];
	QueryPerformanceCounter(&End);
	printf("64 bytes step access %f ms\n", (End.QuadPart - Start.QuadPart) / freq_ms);
	
	free(ptr);
	return sum;
}
