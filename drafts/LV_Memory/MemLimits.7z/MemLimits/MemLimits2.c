//==============================================================================
//
// Title:		MemLimits
// Purpose:		A short description of the command-line tool.
//
// Created on:	19.04.2025 at 07:19:09 by Andrey Dmitriev.
// Copyright:	GE Inspection Technologies GmbH. All Rights Reserved.
//
//==============================================================================

#include <windows.h>
#include <ansi_c.h>
#include <utility.h>

#define MB 1024*1024
int main (int argc, char *argv[])
{
	printf("Memory Test - Hit any key to continue\n"); GetKey ();
	uint8_t* ptr = (uint8_t*)malloc(1024 * MB);
	printf("1 GiB allocated\n"); GetKey ();
	ZeroMemory(ptr, 1024 * MB);
	printf("1 GiB zeroed\n"); GetKey ();
	free(ptr);
	printf("1 GiB released\n"); GetKey ();
	return 0;
}
