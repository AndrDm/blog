//==============================================================================
//
// Title:		CacheEstimations2
// Purpose:		A short description of the command-line tool.
//
// Created on:	21.04.2025 at 22:50:25 by Andrey Dmitriev.
// Copyright:	GE Inspection Technologies GmbH. All Rights Reserved.
//
//==============================================================================

#include <windows.h>
#include <ansi_c.h>

#define MIN_SIZE (1 << 10)  // 1 KB
#define MAX_SIZE (1 << 27)  // 128 MB
#define STRIDE 64
#define ITERATIONS 100000000

void measure_latency(size_t size) {
	
	LARGE_INTEGER Start, End;
	
    // Allocate and initialize memory
    char *mem = malloc(size);
    for (size_t i = 0; i < size; i += 64) mem[i] = (char)i;
    
    // Pointer chasing to create stride accesses
    volatile char **ptr = (volatile char **)mem;
    for (size_t i = 0; i < size / sizeof(char *); i += STRIDE / sizeof(char *)) {
        ptr[i] = (char *)&ptr[(i + STRIDE) % (size / sizeof(char *))];
    } //The pointer chasing pattern prevents hardware prefetcher optimizations, 
	// giving more accurate latency measurements.

    // Warm-up and timing measurement
    volatile char **p = ptr;
	volatile char sum = 0;
	QueryPerformanceCounter(&Start);
    for (int i = 0; i < ITERATIONS; i++) {
		sum += **p;
		p = (volatile char **)*p;
    }  
    // Calculate latency per access (ns)
	QueryPerformanceCounter(&End);
    double latency = (End.QuadPart - Start.QuadPart) * 100.0 / ITERATIONS; //100 th nanoseconds
    printf("Buffer size: %zu KiB, Latency: %.2f ns %d\n", size/1024, latency, sum);
    
    free(mem);
}

int main() {
	LARGE_INTEGER Freq;
	QueryPerformanceFrequency (&Freq);
 	double freq = (double)Freq.QuadPart;
	printf("freq %.2f\n",freq);
	
    for (size_t size = MIN_SIZE; size <= MAX_SIZE; size *= 2) measure_latency(size);
 
    return 0;
}