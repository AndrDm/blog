//==============================================================================
//
// Title:		MemLimits
// Purpose:		A short description of the command-line tool.
//
// Created on:	19.04.2025 at 07:19:09 by Andrey Dmitriev.
// https://learn.microsoft.com/en-us/windows/win32/sysinfo/acquiring-high-resolution-time-stamps
//==============================================================================

#include <windows.h>
#include <ansi_c.h>
#include <utility.h>

#define MB 1024*1024
int main (int argc, char *argv[])
{
	
	LARGE_INTEGER StartingTime, EndingTime, ElapsedMilliseconds;
	LARGE_INTEGER Frequency;
	QueryPerformanceFrequency(&Frequency); 

	uint8_t* ptr = (uint8_t*)malloc(1024 * MB);

	QueryPerformanceCounter(&StartingTime);
	// Activity to be timed
	ZeroMemory(ptr, 1024 * MB);
	
	QueryPerformanceCounter(&EndingTime);
	ElapsedMilliseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
	ElapsedMilliseconds.QuadPart *= 1000;
	ElapsedMilliseconds.QuadPart /= Frequency.QuadPart;
	printf("First ZeroMemory %d ms\n", ElapsedMilliseconds.QuadPart);
	
	QueryPerformanceCounter(&StartingTime);
	// Activity to be timed
	ZeroMemory(ptr, 1024 * MB);
	QueryPerformanceCounter(&EndingTime);
	
	ElapsedMilliseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
	ElapsedMilliseconds.QuadPart *= 1000;
	ElapsedMilliseconds.QuadPart /= Frequency.QuadPart;
	
	printf("Second ZeroMemory %d ms\n", ElapsedMilliseconds.QuadPart);
	
	free(ptr);
	return 0;
}
