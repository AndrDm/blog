//==============================================================================
//
// Title:		32gbtest
// Purpose:		A short description of the command-line tool.
//
// Created on:	14.05.2025 at 05:05:17 by Andrey Dmitriev.
// Copyright:	GE Inspection Technologies GmbH. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <ansi_c.h>
#include <windows.h>

#define GIBIBYTE 1073741824ULL  // 1024^3
#define CHUNKS 32

int main() {
    void* pointers[CHUNKS]={0};
    size_t alloc = 0;
	
	    HMODULE hModule = GetModuleHandle(NULL);
    printf("Base address: %p\n", (void*)hModule);

    // Allocate 32 GiB in 1 GiB chunks
    for (alloc = 0; alloc < CHUNKS; alloc++) {
        pointers[alloc] = malloc(GIBIBYTE);
        if (!pointers[alloc]) {
            printf("Failed to allocate chunk %d\n", alloc);
            return 1;
        }
        printf("Allocated 1 GiB at: %010p\n", pointers[alloc]);
    }

    printf("\nSuccessfully allocated %zu GiB. Hit Enter to free...", alloc);
    getchar();

    // Free all allocations
    for (int i = 0; i < alloc; i++) free(pointers[i]);
    printf("Memory freed\n");

    return 0;
}

