//==============================================================================
//
// Title:		SHA256CVI
// Purpose:		A short description of the interface.
//
// Created on:	04.12.2024 at 16:51:27 by AD.
//
//==============================================================================

#ifndef __SHA256CVI_H__
#define __SHA256CVI_H__

#ifdef __cplusplus
    extern "C" {
#endif

#include "cvidef.h"
		
#include "include\extcode.h"

typedef struct {
	int32_t dimSize;
	uint8_t elt[1];
	} TD1;
typedef TD1 **TD1Hdl;

void sha256(TD1Hdl buffer, TD1Hdl digest);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __SHA256CVI_H__ */
