//==============================================================================
//
// Title:		SHA256CVI
// Purpose:		SHA256 in C implementation.
//
// Created on:	04.12.2024 at 16:51:27 by AD.
//
//==============================================================================

#include <utility.h>
#include "SHA256CVI.h"
#include "sha256.h"

void sha256(TD1Hdl buffer, TD1Hdl digest)
{
#ifdef _CVI_DEBUG_
	DbgPrintf("Len = %d", (*buffer)->dimSize);
#endif
	
	NumericArrayResize(uB, 1, (UHandle*)(&(digest)), SHA256_BLOCK_SIZE);
	(*digest)->dimSize = SHA256_BLOCK_SIZE;
	
	SHA256_CTX ctx;
	sha256_init(&ctx);
	sha256_update(&ctx, &((*buffer)->elt[0]), (*buffer)->dimSize);
	sha256_final(&ctx, &((*digest)->elt[0]));
}

//==============================================================================
// DLL main entry-point functions

int __stdcall DllMain (HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	switch (fdwReason) {
		case DLL_PROCESS_ATTACH:
			if (InitCVIRTE (hinstDLL, 0, 0) == 0)
				return 0;	  /* out of memory */
			break;
		case DLL_PROCESS_DETACH:
			CloseCVIRTE ();
			break;
	}
	
	return 1;
}
